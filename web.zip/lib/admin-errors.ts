export function adminErrorMessage(error: unknown, fallback: string) {
  const message = error && typeof error === 'object' && 'message' in error ? String(error.message) : ''
  if (/invalid api key|missing supabase|invalid jwt/i.test(message)) {
    return 'The store connection could not be verified. Please check the server’s Supabase credentials.'
  }
  return fallback
}
