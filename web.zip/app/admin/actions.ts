'use server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { requireAdmin } from '@/lib/admin'
import { createAdminClient } from '@/lib/supabase/server'
import { adminErrorMessage } from '@/lib/admin-errors'
import { UUID_PATTERN, validateProduct, type ProductActionState } from '@/lib/products'

function n(v:FormDataEntryValue|null){return Number(v||0)}
async function mustSave(request:PromiseLike<{error:{message?:string}|null}>) {
  const { error } = await request
  if (error) {
    // Convert backend/store errors into a friendlier, non-technical message when possible
    throw new Error(adminErrorMessage(error, error.message || 'Save failed'))
  }
}
export async function saveCategory(fd:FormData){
 await requireAdmin();const a=createAdminClient();const id=String(fd.get('id')||'');const data={name:String(fd.get('name')||''),slug:String(fd.get('slug')||''),is_active:fd.get('is_active')==='on'}
 if(id)await mustSave(a.from('categories').update(data).eq('id',id));else await mustSave(a.from('categories').insert(data))
 revalidatePath('/admin/categories')
}
export async function deleteCategory(fd:FormData){await requireAdmin();await createAdminClient().from('categories').delete().eq('id',String(fd.get('id')));revalidatePath('/admin/categories')}
export async function saveRate(fd:FormData){
 await requireAdmin();const a=createAdminClient();const id=String(fd.get('id')||'');const data={effective_date:String(fd.get('effective_date')),rate_per_gram:n(fd.get('rate_per_gram'))}
 if(id)await mustSave(a.from('silver_rates').update(data).eq('id',id));else await mustSave(a.from('silver_rates').insert(data))
 revalidatePath('/admin/rates');revalidatePath('/');redirect('/admin/rates')
}
export async function deleteRate(fd:FormData){await requireAdmin();await createAdminClient().from('silver_rates').delete().eq('id',String(fd.get('id')));revalidatePath('/admin/rates')}
export async function saveProduct(_previous: ProductActionState, fd: FormData): Promise<ProductActionState> {
  await requireAdmin()
  const id = String(fd.get('id') || '')
  if (id && !UUID_PATTERN.test(id)) return { error: 'This product could not be found. Return to the product list and try again.' }
  const { values, fieldErrors, valid } = validateProduct(fd)
  if (!valid) return { error: 'Please check the highlighted fields.', fieldErrors }

  let uploadedPath: string | undefined
  let admin: ReturnType<typeof createAdminClient> | undefined
  try {
    admin = createAdminClient()
    let image_url: string | null = null
    if (id) {
      const { data: existing, error } = await admin.from('products').select('image_url').eq('id', id).maybeSingle()
      if (error) throw error
      if (!existing) return { error: 'This product no longer exists. Return to the product list.' }
      image_url = existing.image_url
    }

    const file = fd.get('image')
    if (file instanceof File && file.size > 0) {
      const extension = file.name.split('.').pop()?.replace(/[^a-z0-9]/gi, '').slice(0, 10) || 'image'
      const path = `${crypto.randomUUID()}.${extension}`
      const { error } = await admin.storage.from('product-images').upload(path, file, { upsert: false, contentType: file.type })
      if (error) return { error: adminErrorMessage(error, 'The photo could not be uploaded. Check that product image storage is available and try again.') }
      uploadedPath = path
      image_url = admin.storage.from('product-images').getPublicUrl(path).data.publicUrl
    }

    const data = { ...values, image_url }
    const result = id
      ? await admin.from('products').update(data).eq('id', id).select('id').maybeSingle()
      : await admin.from('products').insert(data).select('id').single()
    if (result.error) throw result.error
    if (!result.data) throw new Error('Product no longer exists')
  } catch (error) {
    if (uploadedPath && admin) {
      // Remove only the new upload if the database save failed; preserve existing photos.
      try { await admin.storage.from('product-images').remove([uploadedPath]) } catch { /* Keep the original save error. */ }
    }
    const code = error && typeof error === 'object' && 'code' in error ? error.code : undefined
    if (code === '23505') return { error: 'That product code is already in use.', fieldErrors: { code: 'Choose a different product code.' } }
    if (code === '23503') return { error: 'The selected category is no longer available.', fieldErrors: { category_id: 'Choose an existing category.' } }
    return { error: adminErrorMessage(error, 'The product could not be saved. Your changes are still here; please try again.') }
  }
  revalidatePath('/admin/products')
  revalidatePath('/')
  if (id) revalidatePath(`/admin/products/${id}/edit`)
  redirect('/admin/products?saved=1')
}

export async function deleteProduct(_previous: ProductActionState, fd: FormData): Promise<ProductActionState> {
  await requireAdmin()
  const id = String(fd.get('id') || '')
  if (!UUID_PATTERN.test(id)) return { error: 'This product could not be found.' }
  try {
    const { data, error } = await createAdminClient().from('products').delete().eq('id', id).select('id').maybeSingle()
    if (error) throw error
    if (!data) return { error: 'This product has already been removed. Refresh the product list.' }
  } catch (error) {
    return { error: adminErrorMessage(error, 'The product could not be deleted. Please try again.') }
  }
  revalidatePath('/admin/products')
  revalidatePath('/')
  return { success: true }
}
export async function updateOrderStatus(fd:FormData){await requireAdmin();await createAdminClient().from('orders').update({status:String(fd.get('status'))}).eq('id',String(fd.get('id')));revalidatePath('/admin/orders')}
