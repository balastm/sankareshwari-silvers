import Header from '@/components/Header'
import Reveal from '@/components/Reveal'
import ProductCard from '@/components/ProductCard'
import { createClient } from '@/lib/supabase/server'
import { todayInIndia } from '@/lib/dates'
import { PRODUCT_COLUMNS, type ProductListItem } from '@/lib/products'

export const revalidate = 30

export default async function Home() {
  const supabase = await createClient()
  const [{data:products,error:productError},{data:rateRow,error:rateError}] = await Promise.all([
    supabase.from('products').select(`${PRODUCT_COLUMNS},category:categories(name)`).eq('is_active',true).order('created_at',{ascending:false}).returns<ProductListItem[]>(),
    supabase.from('silver_rates').select('rate_per_gram,effective_date').lte('effective_date',todayInIndia()).order('effective_date',{ascending:false}).limit(1).maybeSingle()
  ])
  const rate = rateError ? 0 : Number(rateRow?.rate_per_gram || 0)
  return <>
    <Header/>
    <main>
      <section className="hero"><div className="container hero-grid">
        <Reveal><div>
          <div className="eyebrow">Pure elegance · priced transparently</div>
          <h1>Silver, refined.</h1>
          <p>Discover timeless silver pieces with pricing linked to today’s silver rate. Clean craft, clear weight and live stock—nothing hidden.</p>
          <div style={{display:'flex',gap:12,marginTop:24,flexWrap:'wrap'}}>
            <a className="btn btn-dark" href="#products">Shop collection</a>
            <span className="btn btn-ghost">{rate > 0 ? `Today’s rate ₹${rate.toLocaleString('en-IN')}/g` : 'Silver rate will be available soon'}</span>
          </div>
        </div></Reveal>
        <Reveal delay={.08}><div className="hero-art"><div className="hero-glow"/><div className="hero-ring"/></div></Reveal>
      </div></section>

      <section id="products" className="section"><div className="container">
        <Reveal><div className="section-head"><div><div className="eyebrow">Current collection</div><h2>Made for everyday shine.</h2></div><p className="muted">Price = weight × today’s silver rate + making charge</p></div></Reveal>
        <div className="grid">{(products||[]).map((p,i)=><Reveal key={p.id} delay={(i%3)*.05}><ProductCard p={p} rate={rate}/></Reveal>)}</div>
        {productError ? <div className="notice" role="status">The collection could not be loaded. Please try again shortly.</div> : !products?.length && <div className="notice">Our collection is coming soon. Please check back shortly.</div>}
      </div></section>
    </main>
    <footer className="footer"><div className="container">© {new Date().getFullYear()} Sankareshwari Silvers · Crafted with care.</div></footer>
  </>
}
