import {saveRate} from '@/app/admin/actions'
export default function RateForm({rate}:{rate?:any}){
 return <form action={saveRate} className="admin-form form">
  {rate&&<input type="hidden" name="id" value={rate.id}/>}
  <div className="form-grid">
   <div className="field"><label>Date</label><input required type="date" name="effective_date" className="input" defaultValue={rate?.effective_date||new Date().toISOString().slice(0,10)}/></div>
   <div className="field"><label>Rate per gram (₹)</label><input required type="number" step=".01" min="0.01" name="rate_per_gram" className="input" defaultValue={rate?.rate_per_gram||''}/></div>
  </div><button className="btn btn-dark">Save rate</button>
 </form>
}
