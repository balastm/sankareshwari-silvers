import {saveCategory} from '@/app/admin/actions'
export default function CategoryForm({category}:{category?:any}){
 return <form action={saveCategory} className="admin-form form">
  {category&&<input type="hidden" name="id" value={category.id}/>}
  <div className="form-grid">
   <div className="field"><label>Category name</label><input required name="name" className="input" defaultValue={category?.name||''}/></div>
   <div className="field"><label>Slug</label><input required name="slug" className="input" defaultValue={category?.slug||''}/></div>
   <label className="span2"><input name="is_active" type="checkbox" defaultChecked={category?category.is_active:true}/> Active</label>
  </div><button className="btn btn-dark">Save category</button>
 </form>
}
