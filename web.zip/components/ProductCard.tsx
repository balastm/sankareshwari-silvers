import AddToCartButton from './AddToCartButton'
import Image from 'next/image'
import { availableStock, formatPrice, productPrice, type ProductListItem } from '@/lib/products'

export default function ProductCard({p, rate}:{p:ProductListItem;rate:number}) {
  const stock = availableStock(p)
  const out = stock === 0
  const price = productPrice(p.weight_grams, p.making_charge, rate)
  return <article className="card">
    <div className="product-media">
      {p.image_url ? <Image src={p.image_url} alt={p.name} width={640} height={640} unoptimized /> : null}
      <span className={`badge ${out?'out':''}`}>{out?'Out of stock':`${stock} pcs available`}</span>
    </div>
    <div className="card-body">
      <div className="product-title">{p.name}</div>
      <div className="meta"><span>{Number(p.weight_grams).toFixed(2)} g</span><span>{Number(p.stock_grams).toFixed(2)} g stock</span></div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',gap:12}}>
        <span className="price">{rate > 0 ? formatPrice(price) : 'Price available soon'}</span>
        <AddToCartButton disabled={out || rate <= 0} unavailableLabel={out ? 'Out of stock' : 'Rate pending'} maxQty={stock} product={{id:p.id,name:p.name,image_url:p.image_url,weight_grams:Number(p.weight_grams),qty:1}}/>
      </div>
    </div>
  </article>
}
