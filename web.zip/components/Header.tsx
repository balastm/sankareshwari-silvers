import Link from 'next/link'
import { createClient } from '@/lib/supabase/server'

export default async function Header() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  return <header className="header"><div className="container header-inner">
    <Link href="/" className="brand">Sankareshwari<span>Silvers</span></Link>
    <nav className="nav">
      <Link href="/#products">Collections</Link>
      <Link href="/cart">Cart</Link>
      {user ? <><Link href="/orders">My Orders</Link><Link className="btn btn-dark" href="/account">Account</Link></>
      : <Link className="btn btn-dark" href="/login">Login</Link>}
    </nav>
  </div></header>
}
